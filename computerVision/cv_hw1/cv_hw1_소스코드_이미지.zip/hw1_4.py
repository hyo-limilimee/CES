import argparse
import numpy as np
import cv2

# 이미지 경로 입력 받음
parser = argparse.ArgumentParser(description="이미지 입력")
parser.add_argument("image_file", help="img 파일 경로")
args = parser.parse_args()

def countingPieces(file):
    # 이미지를 컬러로 읽기
    src = cv2.imread(file, cv2.IMREAD_COLOR)
    # 이미지 읽기 예외처리
    if src is None:
        print('Image load failed!')
        return

    # 이미지 크기 조절
    resized_src = cv2.resize(src, (800, 800))

    # 캐니 엣지 검출
    edge = cv2.Canny(resized_src, 100, 200)

    # 허프 원 탐색을 통해 원 검출
    circles = cv2.HoughCircles(edge, cv2.HOUGH_GRADIENT, dp=1, minDist=50,
                               param1=250, param2=30, minRadius=10, maxRadius=50)

    # 밝은 색 동그라미와 어두운 색 동그라미 개수 초기화
    bright_count = 0
    dark_count = 0

    # 중간값 계산
    overall_median = np.median(resized_src)

    # 검출한 부분을 처리
    if circles is not None:
        circles = np.uint16(np.around(circles))
        median_values = []

        for i in circles[0, :]:
            # 원의 반지름의 절반 정도의 부분만 추출
            radius_half = int(i[2] * 0.5)
            roi = resized_src[i[1] - radius_half:i[1] + radius_half, i[0] - radius_half:i[0] + radius_half]

            # 추출한 부분의 중간값 계산
            median_value = np.median(roi)
            median_values.append(median_value) 

        #원에서 추출한 모든 부분의 중간 값 계산
        overall_median_of_regions = np.median(median_values)

        # 밝은 색 동그라미와 어두운 색 동그라미 개수 초기화
        bright_count = 0
        dark_count = 0

        # 비교 및 동그라미 그리기
        for i, median_value in zip(circles[0, :], median_values):
            # 중간값을 기준으로 빨간색 또는 노란색으로 표시
            if median_value < overall_median_of_regions:
                color = (0, 0, 255)  # 빨간색
                dark_count += 1
            else:
                color = (0, 255, 255)  # 노란색
                bright_count += 1

            cv2.circle(resized_src, (i[0], i[1]), i[2], color, 2)

        print(f"w: {bright_count}")
        print(f"b: {dark_count}")
        # cv2.imshow('dst', resized_src)
        # cv2.waitKey()
        # cv2.destroyAllWindows()

countingPieces(args.image_file)
