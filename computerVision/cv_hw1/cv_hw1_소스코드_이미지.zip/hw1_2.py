import argparse

# 이미지 경로 입력 받음
parser = argparse.ArgumentParser(description = "이미지 입력")
parser.add_argument("image_file",help="img 파일 경로")
args = parser.parse_args()

import sys
import numpy as np
import cv2

# 마우스 이벤트  함수
def on_mouse(event, x, y, flags, param):
    global cnt, src_pts
    # 좌 클릭 이벤트 처리
    if event == cv2.EVENT_LBUTTONDOWN:
        #최대 4개 점 클릭하게 함
        if cnt < 4:
            src_pts[cnt, :] = np.array([x, y]).astype(np.float32)
            cnt += 1
            # 선택한 점에 원 그림
            cv2.circle(src, (x, y), 5, (0, 0, 255), -1)
            cv2.imshow('src', src)
        # 네 점에 대해 perspective transform
        if cnt == 4:
            w = 200
            h = 300

            dst_pts = np.array([[0, 0],
                                [w - 1, 0],
                                [w - 1, h - 1],
                                [0, h - 1]]).astype(np.float32)

            pers_mat = cv2.getPerspectiveTransform(src_pts, dst_pts)
            
            # 결과 창 표시
            cv2.namedWindow('dst', flags = cv2.WINDOW_NORMAL)
            dst = cv2.warpPerspective(src, pers_mat, (w, h))
            cv2.resizeWindow('dst', 600, 600)
            cv2.imshow('dst', dst)


cnt = 0
src_pts = np.zeros([4, 2], dtype=np.float32)
src = cv2.imread(args.image_file)

if src is None:
    print('Image load failed!')
    sys.exit()

cv2.namedWindow('src', flags = cv2.WINDOW_NORMAL)
cv2.resizeWindow('src', 600, 600)
cv2.setMouseCallback('src', on_mouse)

cv2.imshow('src', src)
cv2.waitKey(0)
cv2.destroyAllWindows()