import argparse

# 이미지 경로 입력 받음
parser = argparse.ArgumentParser(description = "이미지 입력")
parser.add_argument("image_file",help="img 파일 경로")
args = parser.parse_args()

import cv2
import numpy as np

def perspectiveTransform(file):
    #이미지 불러오기
    src = cv2.imread(file, cv2.IMREAD_COLOR)
    if src is None:
        print(f'Image load failed: {file}')
        return

    # 엣지 검출
    edge = cv2.Canny(src, 50, 150)

    # 잡음 제거
    blurred = cv2.GaussianBlur(edge, (0, 0), 1)

    # 이진화
    _, thr = cv2.threshold(blurred, 50, 255, cv2.THRESH_BINARY)

    # 팽창 연산
    kernel = np.ones((5, 5), np.uint8)
    dilated = cv2.dilate(thr, kernel, iterations=1)

    # 외곽선 검출
    contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_TC89_L1)

    max_area = 0
    max_contour = None

    # 외곽선 중 가장 큰 면적을 가진 외곽선 선택 (보드판을 찾기 위함)
    for contour in contours:
        area = cv2.contourArea(contour)
        if area > max_area:
            max_area = area
            max_contour = contour

    # 선택한 외곽선의 모양을 근사화하여 꼭짓점 찾음
    if max_contour is not None:
        epsilon = 0.03 * cv2.arcLength(max_contour, True)   # 외곽선 길이 계산 (epsilon 조절하여 정교화 정도 설정)
        approx = cv2.approxPolyDP(max_contour, epsilon, True)   #외곽선 근사화 -> 다각형 검출

        if len(approx) == 4:
            # 다각형의 중심을 계산
            center = np.mean(approx, axis=0)

            # 다각형의 각도를 계산
            angles = np.arctan2(approx[:, 0, 1] - center[0, 1], approx[:, 0, 0] - center[0, 0])
            # "https://numpy.org/doc/stable/reference/generated/numpy.arctan2.html와 
            # https://m.blog.naver.com/PostView.naver?blogId=heennavi1004&logNo=222031099948&categoryNo=37&proxyReferer="를 참고해서 작성

            # 각도를 기준으로 정렬 
            sorted_indices = np.argsort(angles)
            approx_sorted = np.array(approx)[sorted_indices]
            pts1 = np.float32(approx_sorted)

            pts2 = np.float32([[0, 0], [600, 0], [600, 600], [0, 600]])

            # perspective transform 실행
            matrix = cv2.getPerspectiveTransform(pts1, pts2)
            dst = cv2.warpPerspective(src, matrix, (600, 600))

           # 이미지 imshow
            cv2.namedWindow('dst', cv2.WINDOW_NORMAL)
            cv2.imshow('dst', dst)
            cv2.waitKey(0)
            cv2.destroyAllWindows()

perspectiveTransform(args.image_file)
