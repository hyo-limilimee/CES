import argparse
import cv2
import numpy as np

# 거리 계산 함수
def distance(point1, point2):
    x1, y1, x2, y2 = point1
    x3, y3, x4, y4 = point2
    return min(np.linalg.norm(np.array([x1, y1]) - np.array([x3, y3])),
               np.linalg.norm(np.array([x2, y2]) - np.array([x4, y4])))

# 겹치는 선을 병합하는 함수
def merge_lines(cluster, new_line):
    merged = False
    for i, line in enumerate(cluster):
        if distance(line, new_line) < 40:
            cluster[i] = ((line[0] + new_line[0]) // 2, (line[1] + new_line[1]) // 2,
                           (line[2] + new_line[2]) // 2, (line[3] + new_line[3]) // 2)
            merged = True
            break
    if not merged:
        cluster.append(new_line)

# 전체 선 개수 계산 함수
def count_lines(clusters):
    num_lines = 0
    for cluster in clusters:
        num_lines += len(cluster)
    return num_lines

# 체커보드 유효성 검사 함수
def validateCheckerBoard(image):
    # 이미지를 그레이스케일로 변환
    src = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # 이미지 크기 조정
    desired_width = 800
    desired_height = 600
    src = cv2.resize(src, (desired_width, desired_height))

    # Canny 엣지 검출
    edge = cv2.Canny(src, 75, 150)

    # 가우시안 블러
    blurred = cv2.GaussianBlur(edge, (1, 1), 0)

    # 허프 선 검출
    lines = cv2.HoughLines(blurred, 1, np.pi / 180, 140)

    # 끝점 검출
    points = []
    if lines is not None:
        for line in lines:
            rho, theta = line[0]
            cos, sin = np.cos(theta), np.sin(theta)
            cx, cy = rho * cos, rho * sin
            x1, y1 = int(cx + 1000 * (-sin)), int(cy + 1000 * cos)
            x2, y2 = int(cx + 1000 * sin), int(cy + 1000 * (-cos))
            points.append((x1, y1, x2, y2))

    # 선 클러스터링
    clusters = []
    for point in points:
        added = False
        for cluster in clusters:
            merge_lines(cluster, point)
            added = True
            break
        if not added:
            clusters.append([point])

    # 전체 선 개수 계산
    num_lines = count_lines(clusters)

    # 검출된 선 그리기
    dst = cv2.cvtColor(src, cv2.COLOR_GRAY2BGR)
    for cluster in clusters:
        color = (125, 125, 0)
        for point in cluster:
            x1, y1, x2, y2 = point
            cv2.line(dst, (x1, y1), (x2, y2), color, 4)

    # 수평 및 수직 선 개수 계산
    horizontal_lines = 0
    vertical_lines = 0
    for cluster in clusters:
        for point in cluster:
            x1, y1, x2, y2 = point
            # 기울기가 수평에 가까운 경우
            if abs(y2 - y1) < abs(x2 - x1):
                horizontal_lines += 1
            else:
                vertical_lines += 1

    cv2.namedWindow('dst', flags=cv2.WINDOW_NORMAL)
    cv2.imshow('dst', dst)

    # 체커보드 타입 결정
    if num_lines <= 20:
        print("8X8")
    else:
        print("10X10")

    cv2.waitKey()

# 주요 함수: 선 검출 및 체커보드 유효성 검사
def detect_lines(image_path):
    # 이미지 읽기
    src = cv2.imread(image_path, cv2.IMREAD_COLOR)
    if src is None:
        print(f'이미지 로드 실패: {image_path}')
        return

    # 엣지 검출
    edge = cv2.Canny(src, 50, 150)

    # 노이즈 감소
    blurred = cv2.GaussianBlur(edge, (0, 0), 1)

    # 이진화
    _, thr = cv2.threshold(blurred, 50, 255, cv2.THRESH_BINARY)

    # 팽창
    kernel = np.ones((5, 5), np.uint8)
    dilated = cv2.dilate(thr, kernel, iterations=1)

    # 윤곽선 검출
    contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_TC89_L1)

    max_area = 0
    max_contour = None

    # 가장 큰 면적의 윤곽선 찾기
    for contour in contours:
        area = cv2.contourArea(contour)
        if area > max_area:
            max_area = area
            max_contour = contour

    # 근사화된 윤곽선으로 꼭지점 찾기
    if max_contour is not None:
        epsilon = 0.03 * cv2.arcLength(max_contour, True)
        approx = cv2.approxPolyDP(max_contour, epsilon, True)

        if len(approx) == 4:
            center = np.mean(approx, axis=0)
            angles = np.arctan2(approx[:, 0, 1] - center[0, 1], approx[:, 0, 0] - center[0, 0])
            sorted_indices = np.argsort(angles)
            approx_sorted = np.array(approx)[sorted_indices]
            pts1 = np.float32(approx_sorted)

            pts2 = np.float32([[0, 0], [600, 0], [600, 600], [0, 600]])

            # perspective transform 진행
            matrix = cv2.getPerspectiveTransform(pts1, pts2)
            transformed = cv2.warpPerspective(src, matrix, (600, 600))

            # 변환된 이미지에서 체커보드 유효성 검사 수행
            validateCheckerBoard(transformed)

    cv2.destroyAllWindows()

if __name__ == "__main__":
    # 이미지 파일 경로 입력 받음
    parser = argparse.ArgumentParser(description="이미지 입력")
    parser.add_argument("image_file", help="img 파일 경로")
    args = parser.parse_args()

    # 이미지 검출 함수 호출
    detect_lines(args.image_file)
