import cv2
import numpy as np
import argparse

# Argument Parsing
parser = argparse.ArgumentParser(description="Template Matching")
parser.add_argument("target_image", help="Filename of the target image")
args = parser.parse_args()

# 이미지 읽기
target_img = cv2.imread(args.target_image, cv2.IMREAD_GRAYSCALE)

# 템플릿 파일 선언
template_files = ["templete_01.jpg", "templete_02.jpg", "templete_03.jpg", "templete_04.jpg", "templete_05.jpg", "templete_06.jpg","templete_07.jpg","templete_08.jpg"]

# SIFT 적용
sift = cv2.SIFT_create()

kp1, des1 = sift.detectAndCompute(target_img, None)

# FLANN Matcher 적용
index_params = dict(algorithm=0, trees=5)
search_params = dict(checks=50)
flann = cv2.FlannBasedMatcher(index_params, search_params)

# 이미지 크기 설정
height, width = target_img.shape[:2]

# ROI (Region of Interest) 정의
roi_horizontal_margin = 0.1  # 폭에 대해서 margin 적용
roi_vertical_margin = 0.0

roi_start = (int(width * roi_horizontal_margin), int(height * roi_vertical_margin))
roi_end = (int(width * (1 - roi_horizontal_margin)), height)

# 최소한 하나의 템플릿이 100개 이상의 좋은 매치를 가지는지 확인
result_flag = False

for template_file in template_files:
    template_img = cv2.imread(template_file, cv2.IMREAD_GRAYSCALE)

    kp2, des2 = sift.detectAndCompute(template_img, None)

    # 첫 번째 조건: 현재 템플릿과의 매칭 확인
    matches = flann.knnMatch(des1, des2, k=2)

    # good matches 선택
    good_matches = []
    for m, n in matches:
        if m.distance < 0.75 * n.distance:
            x, y = kp1[m.queryIdx].pt
            # 키포인트가 ROI 내에 있는지 확인
            if roi_start[0] < x < roi_end[0] and roi_start[1] < y < roi_end[1]:
                good_matches.append(m)

    # print(f"Number of matches for template {template_file}: {len(good_matches)}")

    # 좋은 매치의 수가 100개 이상인지 확인
    if len(good_matches) >= 100:
        result_flag = True

# 최종 결과 출력
print(f"{result_flag}")