import cv2
import numpy as np
import argparse

# Argument Parsing
parser = argparse.ArgumentParser(description="Template Matching")
parser.add_argument("target_image", help="대상 이미지 파일명")
args = parser.parse_args()

# 컬러 이미지로 대상 이미지 읽기 (BGR)
target_img_color = cv2.imread(args.target_image)
# 대상 이미지를 그레이스케일로 변환
target_img = cv2.cvtColor(target_img_color, cv2.COLOR_BGR2GRAY)

# 템플릿 이미지 파일명 리스트
template_files = ["templete_01.jpg", "templete_02.jpg", "templete_03.jpg", "templete_04.jpg", "templete_05.jpg", "templete_06.jpg", "templete_07.jpg", "templete_08.jpg"]

# SIFT 초기화
sift = cv2.SIFT_create()

# 대상 이미지의 키포인트와 디스크립터 계산
kp1, des1 = sift.detectAndCompute(target_img, None)

# FLANN Matcher 초기화
index_params = dict(algorithm=0, trees=5)
search_params = dict(checks=50)
flann = cv2.FlannBasedMatcher(index_params, search_params)

# 이미지 크기
height, width = target_img.shape[:2]

# ROI (Region of Interest) 정의
roi_horizontal_margin = 0.1  # 가로폭의 20% 마진
roi_vertical_margin = 0.0  # 세로 높이에는 마진 없음

roi_start = (int(width * roi_horizontal_margin), int(height * roi_vertical_margin))
roi_end = (int(width * (1 - roi_horizontal_margin)), height)

# 가장 많은 매칭을 추적하기 위한 변수
max_matches = 0
best_template = None
best_rect_start = None
best_rect_end = None

# 반복문 밖에서 img_with_rect 초기화
img_with_rect = target_img_color.copy()  # 컬러 이미지로 초기화

for template_file in template_files:
    # 템플릿 이미지 읽기
    template_img = cv2.imread(template_file, cv2.IMREAD_GRAYSCALE)

    # 템플릿 이미지의 키포인트와 디스크립터 계산
    kp2, des2 = sift.detectAndCompute(template_img, None)

    # 현재 템플릿과 매칭 확인
    matches = flann.knnMatch(des1, des2, k=2)

    # goodmatches 선택
    good_matches = []
    for m, n in matches:
        if m.distance < 0.75 * n.distance:
            x, y = kp1[m.queryIdx].pt
            # 키포인트가 ROI 내에 있는지 확인
            if roi_start[0] < x < roi_end[0] and roi_start[1] < y < roi_end[1]:
                good_matches.append(m)

    # goodmatches가 현재 최대보다 큰지 확인
    if len(good_matches) > max_matches:
        max_matches = len(good_matches)
        best_template = template_file

        # goodmatches의 좌표 추출
        good_matches_points = np.float32([kp1[m.queryIdx].pt for m in good_matches])

        # goodmatches을 포함하는 사각형의 좌표 계산
        x, y, w, h = cv2.boundingRect(good_matches_points)

        # 경계 상자 좌표를 조절
        scale_factor_width = 0.35 
        w_scaled = int(w * scale_factor_width)
        rect_start = (x + w//2 - w_scaled//2, y)
        rect_end = (x + w//2 + w_scaled//2, y + h)

        # 가장 좋은 매칭의 좌표 저장
        best_rect_start = rect_start
        best_rect_end = rect_end


# 가장 goodmatches 수가 많은 템플릿 선택
if best_template and max_matches >= 100:
    # 결과 이미지에 경계 상자 그리기
    cv2.rectangle(img_with_rect, best_rect_start, best_rect_end, (0, 0, 255), 3)  # 빨간색, 선 두께=3

# 경계 상자와 함께 이미지 표시 또는 저장
window_name = "result_image"
cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
cv2.imshow(window_name, img_with_rect)
cv2.waitKey(0)
cv2.destroyAllWindows()